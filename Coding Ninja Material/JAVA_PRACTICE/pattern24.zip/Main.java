/******************************************************************************

1      1
 2    2
  3 3
   4
  3 3
 2   2
1     1

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int i=1;
		int p = n-1;
		while(i<=2*n-1){
		    if(i<=n){
		        int space = i-1;
		        while(space>=1){
		            System.out.print(" ");
		            space--;
		        }
		        int num = i;
		        while(num<=n){
		            if(num==i){
		                System.out.print(num);
		            }
		            else{
		                System.out.print(" ");
		            }
		            num++;
		        }
		        
		        num = num-2;
		        while(num>=1){
		            if(num==i){
		                System.out.print(num);
		            }
		            else{
		                System.out.print(" ");
		            }
		            num--;
		        }
		        
		    }
		    else{
		        int space = 2*n-i-1;
		        while(space>=1){
		            System.out.print(" ");
		            space--;
		        }
		        int num = 2*n-i;
		        while(num<=n){
		            if(num==p){
		                System.out.print(num);
		            }
		            else{
		                System.out.print(" ");
		            }
		            num++;
		        }
		        num = num-2;
		        while(num>=1){
		            if(num==p){
		                System.out.print(num);
		            }
		            else{
		                System.out.print(" ");
		            }
		            num--;
		        }
		        p = p-1;
		    }
		    System.out.println();
		    i++;
		}
	}
}
