/******************************************************************************

1
11
202
3003


*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int i=1;
	    System.out.println(1);
		while(i<=n-1){
		    int j=1;
		    int k=1;
		    while(j<=i){
		        k = k*10;
		        j++;
		    }
		    System.out.println(k*i+i);
		    i++;
		    
		}
	}
}
