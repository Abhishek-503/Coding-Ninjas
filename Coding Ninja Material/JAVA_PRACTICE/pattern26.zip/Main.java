/******************************************************************************

4
****
 ****
  ****
   ****


*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int i = 1;
        while(i<=n){
            int space = i-1;
            while(space>=1){
                System.out.print(' ');
                space--;
            }
            int j = 1;
            while(j<=n){
                System.out.print('*');
                j++;
            }
            System.out.println();
            i++;
        }
	}
}
