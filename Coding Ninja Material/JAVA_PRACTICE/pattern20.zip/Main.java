/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        int n= sc.nextInt();
        
        if(1<=n && n<=49){
            
            if(n%2!=0){
                int i=1;
                int p = n-2;
                int space;
                while(i<=n){
                    int check = 2*i-1;
                                  
                    if(check<=n){
                        space  = n/2-i+1;
                        while(space>=1){
                            System.out.print(' ');
                            space--;
                        }
                        int star = 1;
                        while(star<=check){
                            System.out.print('*');
                            star++;
                    	}
                    }
                    else{
                        space = i-(n/2)-1;
                        while(space>=1){
                            System.out.print(' ');
                            space--;
                        }
                        int star = p;
                        while(star>=1){
                            System.out.print('*');
                            star--;
                        }
                        p = p-2;
                    }
                    
                    i++;
                    System.out.println();
                }
            }
           
        }
	}
}
