/******************************************************************************
4555
3455
2345
1234


*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int i=n;
		while(i>=1){
		    int j=1;
		    int p = i;
		    while(j<=n-i+1){
		        System.out.print(p);
		        p = p+1;
		        j++;
		    }
		    while(j<=n){
		        System.out.print(n+1);
		        j++;
		    }
		    System.out.println();
		    i--;
		}
	}
}
