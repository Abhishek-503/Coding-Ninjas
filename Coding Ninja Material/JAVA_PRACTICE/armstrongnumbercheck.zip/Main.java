/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int num = 0;
		int sum = 0;
		int num1 = n;
		while(num1!=0){
		    num = num + 1;
		    num1 = num1/10;
		}
		num1 = n;
		while(num1!=0){
		    int rem = num1%10;
		    
		    sum = sum + (int)Math.pow(rem,num);
		    num1 = num1/10;
		}
		if(sum==n){
		    System.out.print(true);
		}
		else{
		    System.out.print(false);
		}
	}
}
