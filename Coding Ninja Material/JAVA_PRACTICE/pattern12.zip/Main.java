/******************************************************************************

ABCD
ABC
AB
A


*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int i = n;
		while(i>=1){
		    int j = 1;
		    char ch = 'A';
		    while(j<=i){
		        System.out.print(ch);
		        ch = (char)(ch+1);
		        j++;
		    }
		    System.out.println();
		    i--;
		}
	}
}
