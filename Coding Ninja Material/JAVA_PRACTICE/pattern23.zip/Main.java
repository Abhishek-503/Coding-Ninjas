/******************************************************************************

   1
  121
 12321
1234321
 12321
  121
   1


*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int i=1;
		int p = n-1;
		while(i<2*n){
		    if(i<=n){
		        int space = n-i;
		        while(space>=1){
		            System.out.print(" ");
		            space--;
		        }
		        int num=1;
		        while(num<=i){
		            System.out.print(num);
		            num++;
		        }
		        num = num-2;
		        while(num>0){
		            System.out.print(num);
		            num--;
		        }
		    }
		    else{
		        int space = i-n;
		        while(space>=1){
		            System.out.print(" ");
		            space--;
		        }
		        int num = 1;
		        while(num<=p){
		            System.out.print(num);
		            num++;
		        }
		        num = num-2;
		        while(num>=1){
		            System.out.print(num);
		            num--;
		        }
		        p = p-1;
		       
		    }
		    System.out.println();
		    i++;
		    
		}
	}
}
