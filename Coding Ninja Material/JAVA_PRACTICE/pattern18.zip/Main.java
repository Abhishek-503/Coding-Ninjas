/******************************************************************************

4
   1
  232
 34543
4567654


*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        if(0<=n && n<=50){
            int i=1;
            while(i<=n){
                
            	int space = 1;
                while(space<=n-i){
                    System.out.print(' ');
                    space++;
                }
                int num1 = i;
                while(num1<=2*i-1){
                    System.out.print(num1);
                    num1++;
                }
                int num2 = 2*(i-1);
                while(num2>=i){
                    System.out.print(num2);
                    num2--;
                }
                System.out.println();
                i++;
            }
            
            
            
        }
	}
}
