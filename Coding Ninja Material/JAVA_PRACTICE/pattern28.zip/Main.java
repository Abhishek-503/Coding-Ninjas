/******************************************************************************

1=1
1+2=3
1+2+3=6
1+2+3+4=10
1+2+3+4+5=15

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int i=1;
		
		while(i<=n){
		    int j = 1;
		    int sum = 0;
		    while(j<=i){
		        sum = sum+j;
		        if(j==i){
		            System.out.println(j+"="+sum);
		        }
		        else{
		            System.out.print(j+"+");
		        }
		        j++;
		    }
		    
		    i++;
		}
	}
}
