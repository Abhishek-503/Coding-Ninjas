/******************************************************************************

13579
35791
57913
79135
91357

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int i = 1;
        int p = 1;
        while(i<=2*n-1){
            int j = 1;
            int k = i;
            while(j<=n-p+1){
                System.out.print(k);
                k=k+2;
                j++;
            }
            k = 1;
            j = p-1;
            while(j>=1){
                System.out.print(k);
                k = k+2;
                j--;
            }
            System.out.println();
            i = i+2;
            p++;
        }
	}
}
