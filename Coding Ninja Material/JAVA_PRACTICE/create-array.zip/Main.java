/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] arr = new int[n];
		arrange(arr,n);
	}
	
	public static void arrange(int[] arr, int n) {
    	//Your code goes here
        
        if(n%2==0){
            int k = 0;
            int temp = 1;
            for(int i=0;i<n/2;i++){
            	arr[k] = temp;
                temp = temp+2;
                k++;
        	}
            temp = temp-1;
            for(int j=n/2;j>0;j--){
                arr[k] = temp;
                temp = temp-2;
                k++;
            }
            printArray(arr);
        }
        else{
            int k = 0;
            int temp = 1;
            for(int i=0;i<n/2+1;i++){
            	arr[k] = temp;
                temp = temp+2;
                k++;
        	}
            temp = temp-3;
            for(int j=n/2;j>0;j--){
                arr[k] = temp;
                temp = temp-2;
                k++;
            }
            printArray(arr);
        }
        
    }
    public static void printArray(int[]arr){
        int n=arr.length;
        for(int i=0;i<n;i++){
            if(i==n-1){
                System.out.print(arr[i]);
            }
            else{
                System.out.print(arr[i]+" ");
            }
        }
    }
    
    
}
