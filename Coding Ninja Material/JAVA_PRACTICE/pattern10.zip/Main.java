/******************************************************************************

4

A
AB
ABC
ABCD


*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int n = sc.nextInt();
	    int i=0;
	    while(i<=n){
	        int j=1;
	        char ch = 'A';
	        while(j<=i){
	            
	            System.out.print(ch);
	            ch = (char)(ch+1);
	            j++;
	        }
	        System.out.println();
	        i++;
	    }
	    
	}
}
