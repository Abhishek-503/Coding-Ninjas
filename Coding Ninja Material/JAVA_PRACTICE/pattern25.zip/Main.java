/******************************************************************************
3

*
*1*
*121*
*12321*
*121*
*1*
*

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
        if(0<=n && n<=50){
           	int i=1;
            System.out.println('*');
            while(i<=n){
                System.out.print('*');
                int j=1;
                while(j<=i){
                    System.out.print(j);
                    j++;
                }
                j = i-1;
                while(j>=1){
                    System.out.print(j);
                    j--;
                }
                System.out.println('*');
                i++;
            }
            i = n-1;
            while(i>=1){
                System.out.print('*');
                int j=1;
                while(j<=i){
                    System.out.print(j);
                    j++;
                }
                j = i-1;
                while(j>=1){
                    System.out.print(j);
                    j--;
                }
                System.out.println("*");
                i--;
            }
            System.out.println('*');
            
        }
	}
}
