/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void increment(int i){
        i++;
    }
    public static void printArray(int[]arr){
        int n=arr.length;
        for(int i=0;i<n;i++){
            System.out.println(arr[i]);
        }
    }

   public static void incrementArray(int[] input){
      // System.out.println(input);
       input=new int[7];
       for(int i=0;i<input.length;i++){
           input[i]=input[i]+1;
       }
   }
    
public static void main(String args[]) {
     //int i=10;
     //increment(i);
     //System.out.println(i);
     int[] arr={1,2,3,4,5};
     incrementArray(arr);
     printArray(arr);
    }
}
