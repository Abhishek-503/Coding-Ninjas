/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
import java.lang.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int res = 0;
        int i = 0;
        while(n!=0){
            int rem = n%10;
            int pow = 1;
            if(i!=0){
                for(int j = 0;j<i;j++){
                    pow = pow*2;
                }
            }
            
//            res = res+rem*(int)Math.pow(2,i);
            res = res+rem*pow;
            n = n/10;
            i++;
        }
        System.out.print(res);
	}
}

